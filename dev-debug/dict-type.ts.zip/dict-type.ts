class Thingy {
  private _name: string;
  constructor(name: string) {
    this._name = name;
  }
  get name() {
    return this._name;
  }
}

const myThingMakers = {
  one: () => new Thingy("one"),
  two: () => new Thingy("two"),
  three: () => new Thingy("three"),
};
const myThingMakersType = typeof myThingMakers;

// const myDict: { [key: string]: string } = {};
const myDict: { [key: keyof typeof myThingMakers]: string } = {};

//
type unionOfKeys = keyof typeof myThingMakers;
const myDictX: { [key in unionOfKeys]?: string } = {};

const myThings: { [thingName: string]: Thingy } = {};
myThings["one"] = myThingMakers.one();
myThings["nine"] = myThingMakers.two();

myDictX["one"] = "one";
myDictX["nine"] = "two";
